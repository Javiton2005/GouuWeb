document.getElementById('close-banner').addEventListener('click', function() {
    document.querySelector('.banner').style.display = 'none';
});